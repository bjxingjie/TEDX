## 1. 架构设计

```mermaid
graph TD
  A[用户浏览器] --> B[React前端应用]
  B --> C[Supabase SDK]
  C --> D[Supabase认证服务]
  C --> E[Supabase数据库]
  C --> F[Supabase存储服务]
  G[OCR识别服务] --> B
  
  subgraph "前端层"
    B
  end
  
  subgraph "后端服务层（Supabase）"
    D
    E
    F
  end
  
  subgraph "外部服务"
    G
  end
```

## 2. 技术描述

- **前端框架**：React@18 + TypeScript + Vite
- **UI组件库**：Ant Design@5 + 自定义组件
- **样式方案**：TailwindCSS@3 + CSS Modules
- **状态管理**：React Context + useReducer
- **图表库**：ECharts@5 + @echarts-for-react
- **图片处理**：react-image-crop + browser-image-compression
- **初始化工具**：vite-init
- **后端服务**：Supabase（认证+数据库+存储）
- **OCR识别**：腾讯云OCR API（数学公式识别，可配置开关，默认关闭）

## 3. 路由定义

| 路由路径 | 页面用途 | 权限要求 |
|----------|----------|----------|
| /login | 登录页面，预置账号登录（妈妈/123，邢洲/456） | 无 |
| /mom/dashboard | 妈妈后台首页，数据总览 | 妈妈角色 |
| /mom/question/add | 错题录入页面 | 妈妈角色 |
| /mom/question/list | 错题管理列表 | 妈妈角色 |
| /mom/analytics | 学情分析页面 | 妈妈角色 |
| /mom/review/settings | 复习任务设置 | 妈妈角色 |
| /child/review | 孩子复习页面 | 孩子角色 |
| /child/history | 复习历史记录 | 孩子角色 |
| /profile | 个人资料设置 | 已登录用户 |

## 4. 数据模型

### 4.1 实体关系图

```mermaid
erDiagram
  USERS ||--o{ QUESTIONS : creates
  USERS ||--o{ REVIEW_SESSIONS : has
  QUESTIONS ||--o{ REVIEW_ITEMS : contains
  REVIEW_SESSIONS ||--o{ REVIEW_ITEMS : includes
  QUESTIONS }o--|| SUBJECTS : belongs_to
  QUESTIONS }o--|| KNOWLEDGE_POINTS : contains
  QUESTIONS }o--|| ERROR_TYPES : classified_as
  
  USERS {
    uuid id PK
    string phone
    string password_hash
    string name
    string role
    timestamp created_at
    timestamp updated_at
  }
  
  QUESTIONS {
    uuid id PK
    uuid user_id FK
    uuid subject_id FK
    string image_url
    string text_content
    string error_reason
    uuid knowledge_point_id FK
    uuid error_type_id FK
    string difficulty
    string source
    boolean is_mastered
    timestamp created_at
  }
  
  REVIEW_SESSIONS {
    uuid id PK
    uuid child_id FK
    string status
    timestamp scheduled_at
    timestamp completed_at
    json performance_data
    timestamp created_at
  }
  
  REVIEW_ITEMS {
    uuid id PK
    uuid review_session_id FK
    uuid question_id FK
    string status
    string feedback
    timestamp answered_at
  }
  
  SUBJECTS {
    uuid id PK
    string name
    string grade
    integer sort_order
  }
  
  KNOWLEDGE_POINTS {
    uuid id PK
    uuid subject_id FK
    string name
    string parent_id
    integer level
  }
  
  ERROR_TYPES {
    uuid id PK
    string name
    string category
    string description
  }
```

### 4.2 数据定义语言

#### 用户表（users）
```sql
CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  username VARCHAR(50) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  name VARCHAR(50) NOT NULL,
  role VARCHAR(10) NOT NULL CHECK (role IN ('mom', 'child')),
  is_preset BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_users_username ON users(username);
CREATE INDEX idx_users_role ON users(role);
```

#### 科目表（subjects）
```sql
CREATE TABLE subjects (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name VARCHAR(20) NOT NULL,
  grade VARCHAR(10) NOT NULL,
  sort_order INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 初始化数据
INSERT INTO subjects (name, grade, sort_order) VALUES
('数学', '小学', 1),
('语文', '小学', 2),
('英语', '小学', 3),
('数学', '初中', 4),
('语文', '初中', 5),
('英语', '初中', 6);

-- 初始化预置用户
INSERT INTO users (username, password_hash, name, role, is_preset) VALUES
('妈妈', '$2b$10$YourHashedPassword123', '妈妈', 'mom', TRUE),
('邢洲', '$2b$10$YourHashedPassword456', '邢洲', 'child', TRUE);
```

#### 错题表（questions）
```sql
CREATE TABLE questions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  subject_id UUID NOT NULL REFERENCES subjects(id),
  image_url TEXT,
  text_content TEXT,
  error_reason VARCHAR(100),
  error_scenario VARCHAR(20) CHECK (error_scenario IN ('日常作业', '小测', '月考', '大考')),
  error_date DATE,
  upload_time TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  knowledge_point_id UUID,
  error_type_id UUID,
  difficulty VARCHAR(10) CHECK (difficulty IN ('easy', 'medium', 'hard')),
  source VARCHAR(50),
  is_mastered BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_questions_user_id ON questions(user_id);
CREATE INDEX idx_questions_subject_id ON questions(subject_id);
CREATE INDEX idx_questions_created_at ON questions(created_at DESC);
```

#### 复习会话表（review_sessions）
```sql
CREATE TABLE review_sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  child_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  status VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending', 'in_progress', 'completed')),
  scheduled_at TIMESTAMP WITH TIME ZONE NOT NULL,
  completed_at TIMESTAMP WITH TIME ZONE,
  performance_data JSONB,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_review_sessions_child_id ON review_sessions(child_id);
CREATE INDEX idx_review_sessions_scheduled_at ON review_sessions(scheduled_at);
```

#### 复习项表（review_items）
```sql
CREATE TABLE review_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  review_session_id UUID NOT NULL REFERENCES review_sessions(id) ON DELETE CASCADE,
  question_id UUID NOT NULL REFERENCES questions(id) ON DELETE CASCADE,
  status VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending', 'passed', 'failed')),
  feedback TEXT,
  answered_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_review_items_session_id ON review_items(review_session_id);
CREATE INDEX idx_review_items_question_id ON review_items(question_id);
```

### 4.3 Supabase RLS策略

#### 基本权限设置
```sql
-- 为匿名用户授予基本读取权限
GRANT SELECT ON subjects TO anon;
GRANT SELECT ON knowledge_points TO anon;
GRANT SELECT ON error_types TO anon;

-- 为认证用户授予完整权限
GRANT ALL PRIVILEGES ON users TO authenticated;
GRANT ALL PRIVILEGES ON questions TO authenticated;
GRANT ALL PRIVILEGES ON review_sessions TO authenticated;
GRANT ALL PRIVILEGES ON review_items TO authenticated;
```

#### RLS策略示例
```sql
-- 用户只能查看自己的数据
CREATE POLICY "用户只能查看自己的信息" ON users
  FOR SELECT USING (auth.uid() = id);

-- 妈妈可以管理自己的错题
CREATE POLICY "妈妈可以管理自己的错题" ON questions
  FOR ALL USING (
    auth.uid() = user_id AND 
    EXISTS (
      SELECT 1 FROM users 
      WHERE users.id = auth.uid() AND users.role = 'mom'
    )
  );

-- 孩子只能查看分配给自己的复习任务
CREATE POLICY "孩子只能查看自己的复习任务" ON review_sessions
  FOR SELECT USING (
    auth.uid() = child_id AND
    EXISTS (
      SELECT 1 FROM users 
      WHERE users.id = auth.uid() AND users.role = 'child'
    )
  );
```

## 5. 核心API接口

### 5.1 认证相关
```typescript
// 用户登录
POST /auth/login
Request: {
  username: string;
  password: string;
}
Response: {
  user: User;
  token: string;
  role: 'mom' | 'child';
}

// OCR配置
GET /api/config/ocr
Response: {
  enabled: boolean;
  provider: string;
  config: object;
}

PUT /api/config/ocr
Request: {
  enabled: boolean;
  provider: string;
  config: object;
}
```

### 5.2 错题管理
```typescript
// 创建错题
POST /api/questions
Request: {
  subjectId: string;
  imageFile?: File;
  textContent?: string;
  errorReason?: string;
  knowledgePointId?: string;
  errorTypeId?: string;
  difficulty?: 'easy' | 'medium' | 'hard';
  source?: string;
}
Response: {
  question: Question;
}

// 获取错题列表
GET /api/questions?subjectId=&knowledgePointId=&errorTypeId=&errorScenario=&startDate=&endDate=&uploadStartDate=&uploadEndDate=&page=&pageSize=
Response: {
  questions: Question[];
  total: number;
  page: number;
  pageSize: number;
}

// 更新错题掌握状态
PUT /api/questions/:id/status
Request: {
  isMastered: boolean;
}
```

### 5.3 学情分析
```typescript
// 获取学情统计数据
GET /api/analytics/overview
Response: {
  totalQuestions: number;
  masteredQuestions: number;
  subjectStats: {
    subjectId: string;
    subjectName: string;
    totalQuestions: number;
    masteredQuestions: number;
    masteryRate: number;
  }[];
}

// 获取薄弱点热力图数据
GET /api/analytics/weak-points
Response: {
  knowledgePoints: {
    id: string;
    name: string;
    errorCount: number;
    totalCount: number;
    errorRate: number;
  }[];
}

// 获取错题趋势
GET /api/analytics/trends?startDate=&endDate=&groupBy=day|week|month
Response: {
  trends: {
    date: string;
    newQuestions: number;
    masteredQuestions: number;
  }[];
}
```

### 5.4 复习任务
```typescript
// 创建复习任务
POST /api/review-sessions
Request: {
  childId: string;
  scheduledAt: string;
  questionIds: string[];
}
Response: {
  reviewSession: ReviewSession;
}

// 获取孩子的复习任务
GET /api/review-sessions/my-reviews
Response: {
  pendingReviews: ReviewSession[];
  completedReviews: ReviewSession[];
}

// 提交复习结果
PUT /api/review-items/:id/status
Request: {
  status: 'passed' | 'failed';
  feedback?: string;
}
```

## 6. 部署建议

### 6.1 本地开发环境
```bash
# 安装依赖
npm install

# 启动开发服务器
npm run dev

# 本地访问
http://localhost:5173
```

### 6.2 环境变量配置
```env
VITE_SUPABASE_URL=your_supabase_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
VITE_TENCENT_OCR_SECRET_ID=your_tencent_ocr_secret_id
VITE_TENCENT_OCR_SECRET_KEY=your_tencent_ocr_secret_key
```

### 6.3 性能优化
- 图片上传前压缩，限制单张图片大小不超过2MB
- 错题列表分页加载，每页20条
- 图表数据缓存，减少重复请求
- 使用React.memo优化组件重渲染