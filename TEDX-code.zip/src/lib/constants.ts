export const SUBJECTS = ['语文', '数学', '英语', '物理', '化学', '生物'];
